# SPDX-License-Identifier: GPL-3.0-or-later
#
# FLED TRIM - Box Trim / Crop for open and non-manifold meshes
# Author: Hawk_eyes42
#
# Draw a box on screen (Object Mode, regular 3D Viewport) and the addon removes
# ALL the geometry that lies inside (or outside) the box, X-ray style: front,
# back, top, bottom - everything the box "goes through" - on the selected mesh
# objects.
#
# The cut is purely geometric (bisect with the 4 planes of the box, then
# deletion of the faces), so it does NOT need a closed / manifold mesh.
# Only the polygons actually crossed by the box border are split: nothing is
# added along the (infinite) extension of the box sides.

bl_info = {
    "name": "FLED TRIM",
    "author": "Hawk_eyes42",
    "version": (1, 2, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar (N) > FLED TRIM  |  Ctrl+Shift+T",
    "description": "Box Trim / Crop for open and non-manifold meshes (scans, photogrammetry)",
    "category": "Mesh",
}

from itertools import compress

import bpy
import bmesh
import gpu
import numpy as np
from bpy.props import EnumProperty
from gpu_extras.batch import batch_for_shader

try:
    import blf
except Exception:  # pragma: no cover
    blf = None


# ---------------------------------------------------------------------------
#  Box math
# ---------------------------------------------------------------------------

def frustum_planes_world(persp, width, height, x0, y0, x1, y1):
    """
    Returns 4 planes (4x4: one row = a,b,c,d) in WORLD space.
    A point p is INSIDE the box when a*x+b*y+c*z+d >= 0 for all planes.
    Works for perspective, orthographic and camera views. In perspective the
    4 half-spaces already enforce w >= 0 (nothing mirrored behind the camera)
    and the volume is unbounded in depth (cut goes through everything).
    """
    P = np.asarray(persp, dtype=np.float64)
    nx0 = 2.0 * x0 / width - 1.0
    nx1 = 2.0 * x1 / width - 1.0
    ny0 = 2.0 * y0 / height - 1.0
    ny1 = 2.0 * y1 / height - 1.0
    return np.array([
        P[0] - nx0 * P[3],   # x >= xmin
        nx1 * P[3] - P[0],   # x <= xmax
        P[1] - ny0 * P[3],   # y >= ymin
        ny1 * P[3] - P[1],   # y <= ymax
    ], dtype=np.float64)


def planes_to_local(planes_world, matrix_world):
    """World planes -> object local space, normalized (n.p + d >= 0 means inside)."""
    Mw = np.asarray(matrix_world, dtype=np.float64)
    pl = planes_world @ Mw
    norms = np.linalg.norm(pl[:, :3], axis=1)
    if np.any(norms < 1e-30):
        return None, None
    pl = pl / norms[:, None]
    return pl[:, :3], pl[:, 3]


# ---------------------------------------------------------------------------
#  Per-polygon "does the box border really cut me?" test (pure Python)
# ---------------------------------------------------------------------------

def _clip_polygon(pts, n, d):
    """Sutherland-Hodgman clip of a convex polygon against n.p + d >= 0."""
    if not pts:
        return []
    out = []
    prev = pts[-1]
    dp = n[0] * prev[0] + n[1] * prev[1] + n[2] * prev[2] + d
    for cur in pts:
        dc = n[0] * cur[0] + n[1] * cur[1] + n[2] * cur[2] + d
        if dc >= 0.0:
            if dp < 0.0:
                t = dp / (dp - dc)
                out.append((prev[0] + (cur[0] - prev[0]) * t,
                            prev[1] + (cur[1] - prev[1]) * t,
                            prev[2] + (cur[2] - prev[2]) * t))
            out.append(cur)
        elif dp >= 0.0:
            t = dp / (dp - dc)
            out.append((prev[0] + (cur[0] - prev[0]) * t,
                        prev[1] + (cur[1] - prev[1]) * t,
                        prev[2] + (cur[2] - prev[2]) * t))
        prev, dp = cur, dc
    return out


def face_needs_cut(pts, N, D, k, eps):
    """
    True only if plane k really cuts the part of the polygon that lies inside
    the other three planes, i.e. if the border of the box passes through the
    polygon. Polygons crossed only by the *extension* of plane k (far outside
    the box) return False, so they are left untouched.
    N, D: lists of 4 normals / offsets (local space).
    """
    n = N[k]
    d = D[k]
    sd = [n[0] * p[0] + n[1] * p[1] + n[2] * p[2] + d for p in pts]
    if max(sd) <= eps or min(sd) >= -eps:
        return False
    poly = pts
    for j in range(4):
        if j == k:
            continue
        poly = _clip_polygon(poly, N[j], D[j])
        if len(poly) < 3:
            return False
    sd = [n[0] * p[0] + n[1] * p[1] + n[2] * p[2] + d for p in poly]
    return max(sd) > eps and min(sd) < -eps


# ---------------------------------------------------------------------------
#  Fast mesh reading (numpy)
# ---------------------------------------------------------------------------

def _attr_int(mesh, name, n):
    out = np.empty(n, dtype=np.int32)
    mesh.attributes[name].data.foreach_get("value", out)
    return out


def _read_mesh(m, need_edges=False):
    nv = len(m.vertices)
    co = np.empty(nv * 3, dtype=np.float32)
    m.vertices.foreach_get("co", co)
    co = co.reshape(nv, 3).astype(np.float64)

    nf = len(m.polygons)
    nl = len(m.loops)
    starts = np.empty(nf, dtype=np.int32)
    cv = np.empty(nl, dtype=np.int32)
    ce = np.empty(nl, dtype=np.int32) if need_edges else None
    if nf:
        try:
            m.polygons.foreach_get("loop_start", starts)
            m.loops.foreach_get("vertex_index", cv)
            if need_edges:
                m.loops.foreach_get("edge_index", ce)
        except (AttributeError, RuntimeError, TypeError):
            # alternative API (internal corner attributes)
            starts = np.asarray(m.polygon_offset_indices, dtype=np.int32)[:nf].copy()
            cv = _attr_int(m, ".corner_vert", nl)
            if need_edges:
                ce = _attr_int(m, ".corner_edge", nl)
    counts = np.diff(np.append(starts, nl)).astype(np.int64) if nf else np.empty(0, np.int64)

    ev = None
    if need_edges:
        ne = len(m.edges)
        ev = np.empty(ne * 2, dtype=np.int32)
        if ne:
            m.edges.foreach_get("vertices", ev)
        ev = ev.reshape(ne, 2)
    return co, starts, counts, cv, ce, ev


def classify(co, starts, counts, cv, N, D, remove_inside):
    """
    Decides what to delete. A face is "inside" when its centroid is inside all
    4 planes; a free vertex (not part of any face: loose points / wire edges)
    is "inside" when its position is.
    Returns (mask of faces to delete, indices of free vertices to delete,
             number of elements that remain).
    """
    nv = len(co)
    nf = len(starts)
    vin = np.ones(nv, dtype=bool)
    fin = np.ones(nf, dtype=bool)
    for k in range(4):
        sd = co @ N[k] + D[k]
        vin &= sd >= 0.0
        if nf:
            # mean vertex distance = centroid distance (linear relation)
            fin &= np.add.reduceat(sd[cv], starts) >= 0.0

    used = np.zeros(nv, dtype=bool)
    if len(cv):
        used[cv] = True
    free_idx = np.nonzero(~used)[0]

    if remove_inside:
        del_f = fin
        del_v = free_idx[vin[free_idx]]
    else:
        del_f = ~fin
        del_v = free_idx[~vin[free_idx]]

    remaining = (nf - int(del_f.sum())) + (len(free_idx) - len(del_v))
    return del_f, del_v, remaining


# ---------------------------------------------------------------------------
#  Trim one object
# ---------------------------------------------------------------------------

def trim_object(obj, planes_world, remove_inside):
    """
    Returns (status, removed_faces, removed_free_vertices)
    status: 'OK' | 'NOTHING' | 'ALL'
    """
    me = obj.data
    if len(me.vertices) == 0:
        return "NOTHING", 0, 0

    N, D = planes_to_local(planes_world, obj.matrix_world)
    if N is None:
        return "NOTHING", 0, 0

    co, starts, counts, cv, ce, ev = _read_mesh(me, need_edges=True)
    nf = len(starts)
    ne = len(ev)

    diag = float(np.linalg.norm(co.max(axis=0) - co.min(axis=0)))
    eps = max(diag * 1e-6, 1e-12)

    # --- candidate polygons: cross a plane AND are not entirely outside any
    #     other plane (cheap numpy pre-filter, exact test comes later) --------
    cand_idx = np.empty(0, dtype=np.int64)
    if nf:
        not_rejected = np.ones(nf, dtype=bool)
        cross_any = np.zeros(nf, dtype=bool)
        for k in range(4):
            sl = (co @ N[k] + D[k])[cv]
            mx = np.maximum.reduceat(sl, starts)
            mn = np.minimum.reduceat(sl, starts)
            not_rejected &= mx > -eps
            cross_any |= (mn < 0.0) & (mx > 0.0)
        cand_idx = np.nonzero(not_rejected & cross_any)[0]

    # --- candidate wire edges (edges that belong to no face) ------------------
    wire_idx = np.empty(0, dtype=np.int64)
    if ne:
        used_e = np.zeros(ne, dtype=bool)
        if len(ce):
            used_e[ce] = True
        w = np.nonzero(~used_e)[0]
        if len(w):
            not_rejected = np.ones(len(w), dtype=bool)
            cross_any = np.zeros(len(w), dtype=bool)
            for k in range(4):
                s = co @ N[k] + D[k]
                a = s[ev[w, 0]]
                b = s[ev[w, 1]]
                not_rejected &= np.maximum(a, b) > -eps
                cross_any |= (a * b) < 0.0
            wire_idx = w[not_rejected & cross_any]

    bm = None
    tmp = None
    try:
        classify_src = (co, starts, counts, cv)

        if len(cand_idx) or len(wire_idx):
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.faces.ensure_lookup_table()
            cand = {bm.faces[i] for i in cand_idx.tolist()}
            wire = set()
            if len(wire_idx):
                bm.edges.ensure_lookup_table()
                wire = {bm.edges[i] for i in wire_idx.tolist()}

            Nl = N.tolist()
            Dl = D.tolist()
            BMFace = bmesh.types.BMFace
            BMEdge = bmesh.types.BMEdge

            for k in range(4):
                geom = set()
                for f in cand:
                    if not f.is_valid:
                        continue
                    pts = [tuple(v.co) for v in f.verts]
                    if face_needs_cut(pts, Nl, Dl, k, eps):
                        geom.add(f)
                        geom.update(f.edges)
                        geom.update(f.verts)
                wire = {e for e in wire if e.is_valid}
                for e in wire:
                    geom.add(e)
                    geom.update(e.verts)
                if not geom:
                    continue

                res = bmesh.ops.bisect_plane(
                    bm, geom=list(geom), dist=eps,
                    plane_co=tuple((-D[k] * N[k]).tolist()),
                    plane_no=tuple(N[k].tolist()),
                )
                for g in res["geom"]:
                    if isinstance(g, BMFace):
                        cand.add(g)
                    elif isinstance(g, BMEdge) and not g.link_faces:
                        wire.add(g)
                cand = {f for f in cand if f.is_valid}

            # temporary copy, only used to read the cut geometry
            tmp = bpy.data.meshes.new("_fled_trim_tmp")
            bm.to_mesh(tmp)
            classify_src = _read_mesh(tmp)[:4]

        co2, starts2, counts2, cv2 = classify_src
        del_f, del_v, remaining = classify(co2, starts2, counts2, cv2, N, D, remove_inside)
        n_f = int(del_f.sum())
        n_v = int(len(del_v))

        if n_f == 0 and n_v == 0:
            return "NOTHING", 0, 0
        if remaining == 0:
            return "ALL", n_f, n_v

        if bm is None:
            bm = bmesh.new()
            bm.from_mesh(me)

        faces_del = list(compress(bm.faces, del_f.tolist())) if n_f else []
        verts_del = []
        if n_v:
            vmask = np.zeros(len(bm.verts), dtype=bool)
            vmask[del_v] = True
            verts_del = list(compress(bm.verts, vmask.tolist()))

        if faces_del:
            bmesh.ops.delete(bm, geom=faces_del, context='FACES')
        verts_del = [v for v in verts_del if v.is_valid]
        if verts_del:
            bmesh.ops.delete(bm, geom=verts_del, context='VERTS')

        bm.to_mesh(me)
        me.update()
        return "OK", n_f, n_v
    finally:
        if bm is not None:
            bm.free()
        if tmp is not None:
            bpy.data.meshes.remove(tmp)


# ---------------------------------------------------------------------------
#  On-screen box drawing
# ---------------------------------------------------------------------------

_shader_cache = {}


def _get_shader():
    sh = _shader_cache.get("flat")
    if sh is None:
        try:
            sh = gpu.shader.from_builtin('UNIFORM_COLOR')
        except Exception:
            sh = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        _shader_cache["flat"] = sh
    return sh


def _fill_rect(shader, x0, y0, x1, y1, color):
    if x1 <= x0 or y1 <= y0:
        return
    verts = ((x0, y0), (x1, y0), (x0, y1), (x1, y1))
    batch = batch_for_shader(shader, 'TRIS', {"pos": verts},
                             indices=((0, 1, 2), (2, 1, 3)))
    shader.uniform_float("color", color)
    batch.draw(shader)


class _State:
    def __init__(self, mode):
        self.mode = mode
        self.region = None
        self.region_ptr = None
        self.rv3d = None
        self.start = None
        self.cur = None
        self.dragging = False


def _draw_callback(st):
    ctx = bpy.context
    region = ctx.region
    if (st.start is None or st.cur is None or region is None
            or region.as_pointer() != st.region_ptr):
        return

    w, h = region.width, region.height
    x0, x1 = sorted((st.start[0], st.cur[0]))
    y0, y1 = sorted((st.start[1], st.cur[1]))
    x0, x1 = max(0, x0), min(w, x1)
    y0, y1 = max(0, y0), min(h, y1)

    shader = _get_shader()
    shader.bind()
    gpu.state.blend_set('ALPHA')

    red = (1.0, 0.22, 0.12, 0.30)
    if st.mode == 'INSIDE':
        _fill_rect(shader, x0, y0, x1, y1, red)
        border = (1.0, 0.35, 0.2, 1.0)
    else:
        _fill_rect(shader, 0, 0, w, y0, red)
        _fill_rect(shader, 0, y1, w, h, red)
        _fill_rect(shader, 0, y0, x0, y1, red)
        _fill_rect(shader, x1, y0, w, y1, red)
        border = (0.25, 0.75, 1.0, 1.0)

    t = 2
    _fill_rect(shader, x0, y0, x1, y0 + t, border)
    _fill_rect(shader, x0, y1 - t, x1, y1, border)
    _fill_rect(shader, x0, y0, x0 + t, y1, border)
    _fill_rect(shader, x1 - t, y0, x1, y1, border)
    gpu.state.blend_set('NONE')

    if blf is not None:
        try:
            label = "REMOVE INSIDE" if st.mode == 'INSIDE' else "REMOVE OUTSIDE"
            blf.size(0, 15.0)
            blf.color(0, 1.0, 1.0, 1.0, 1.0)
            blf.position(0, x0 + 6, min(y1 + 6, h - 22), 0)
            blf.draw(0, label)
        except Exception:
            pass


# ---------------------------------------------------------------------------
#  Main operator
# ---------------------------------------------------------------------------

_NAV_EVENTS = {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE',
               'TRACKPADPAN', 'TRACKPADZOOM', 'MOUSEROTATE'}


class FLEDTRIM_OT_box_trim(bpy.types.Operator):
    bl_idname = "fled_trim.box_trim"
    bl_label = "FLED TRIM - Box Trim"
    bl_description = ("Draw a box on screen and remove the geometry inside or outside of it "
                      "on the selected mesh objects (works on open / non-manifold meshes)")
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    # -- helpers -------------------------------------------------------------
    def _status(self, context):
        mode = "INSIDE" if self._st.mode == 'INSIDE' else "OUTSIDE"
        context.workspace.status_text_set(
            f"FLED TRIM  |  LMB drag: draw box  |  TAB: toggle inside/outside (now: remove {mode})"
            f"  |  MMB: orbit  |  ESC / RMB: cancel"
        )

    def _cleanup(self, context):
        if getattr(self, "_handle", None) is not None:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None
        try:
            context.workspace.status_text_set(None)
        except Exception:
            pass
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass
        if context.area:
            context.area.tag_redraw()

    @staticmethod
    def _region_at(area, event):
        mx, my = event.mouse_x, event.mouse_y
        for r in area.regions:
            if (r.type == 'WINDOW' and r.x <= mx < r.x + r.width
                    and r.y <= my < r.y + r.height):
                return r
        return None

    # -- life cycle ----------------------------------------------------------
    def invoke(self, context, event):
        if context.mode != 'OBJECT':
            self.report({'WARNING'}, "FLED TRIM works in Object Mode: leave Edit/Sculpt Mode first.")
            return {'CANCELLED'}
        if not [o for o in context.selected_objects if o.type == 'MESH']:
            self.report({'WARNING'}, "Select at least one mesh object to trim.")
            return {'CANCELLED'}

        self._st = _State(context.scene.fled_trim_mode)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            _draw_callback, (self._st,), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        context.window.cursor_modal_set('CROSSHAIR')
        self._status(context)
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self._cleanup(context)

    def modal(self, context, event):
        st = self._st
        area = context.area
        if area is None:
            self._cleanup(context)
            return {'CANCELLED'}

        # view navigation is always allowed
        if event.type in _NAV_EVENTS or event.type.startswith('NUMPAD'):
            return {'PASS_THROUGH'}

        if event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            self._cleanup(context)
            return {'CANCELLED'}

        if event.type == 'TAB' and event.value == 'PRESS':
            st.mode = 'OUTSIDE' if st.mode == 'INSIDE' else 'INSIDE'
            context.scene.fled_trim_mode = st.mode
            self._status(context)
            area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            if st.dragging and st.region is not None:
                st.cur = (event.mouse_x - st.region.x, event.mouse_y - st.region.y)
                area.tag_redraw()
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                region = self._region_at(area, event)
                if region is not None:
                    st.region = region
                    st.region_ptr = region.as_pointer()
                    st.rv3d = region.data
                    st.start = st.cur = (event.mouse_x - region.x, event.mouse_y - region.y)
                    st.dragging = True
                    area.tag_redraw()
            elif event.value == 'RELEASE' and st.dragging:
                st.dragging = False
                st.cur = (event.mouse_x - st.region.x, event.mouse_y - st.region.y)
                w, h = st.region.width, st.region.height
                x0, x1 = sorted((st.start[0], st.cur[0]))
                y0, y1 = sorted((st.start[1], st.cur[1]))
                x0, x1 = max(0, x0), min(w, x1)
                y0, y1 = max(0, y0), min(h, y1)
                if (x1 - x0) < 4 or (y1 - y0) < 4:
                    st.start = st.cur = None      # box too small: try again
                    area.tag_redraw()
                    return {'RUNNING_MODAL'}

                self._apply(context, st, x0, y0, x1, y1)
                self._cleanup(context)
                return {'FINISHED'}
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    # -- apply the cut ---------------------------------------------------------
    def _apply(self, context, st, x0, y0, x1, y1):
        planes = frustum_planes_world(
            st.rv3d.perspective_matrix, st.region.width, st.region.height, x0, y0, x1, y1)
        remove_inside = (st.mode == 'INSIDE')

        total_f = total_v = done = 0
        for obj in [o for o in context.selected_objects if o.type == 'MESH']:
            if obj.data.library is not None:
                self.report({'WARNING'}, f"{obj.name}: data linked from a library, skipped.")
                continue
            # meshes shared by several objects: make them unique, otherwise the
            # cut would be applied twice with different matrices
            if obj.data.users - int(obj.data.use_fake_user) > 1:
                obj.data = obj.data.copy()
                self.report({'INFO'}, f"{obj.name}: shared mesh made single-user before trimming.")
            try:
                status, nf, nv = trim_object(obj, planes, remove_inside)
            except Exception as ex:  # noqa
                import traceback
                traceback.print_exc()
                self.report({'ERROR'}, f"{obj.name}: {ex}")
                continue
            if status == 'OK':
                total_f += nf
                total_v += nv
                done += 1
            elif status == 'ALL':
                self.report({'WARNING'},
                            f"{obj.name}: the cut would remove ALL the geometry, "
                            f"skipped for this object (check Inside/Outside).")
            else:
                self.report({'INFO'}, f"{obj.name}: no geometry to remove inside the box.")

        if done:
            extra = f" + {total_v} loose points/vertices" if total_v else ""
            self.report({'INFO'}, f"FLED TRIM: removed {total_f} faces{extra} on {done} object(s).")


# ---------------------------------------------------------------------------
#  Uninstall (Preferences > Add-ons > FLED TRIM)
# ---------------------------------------------------------------------------

def _manual_uninstall_popup(reason):
    def draw(self, context):
        col = self.layout.column()
        col.label(text="Automatic uninstall failed:")
        col.label(text=str(reason)[:90])
        col.separator()
        col.label(text="Do it manually: Edit > Preferences > Add-ons,")
        col.label(text="open the arrow next to FLED TRIM and choose Uninstall / Remove.")
    bpy.context.window_manager.popup_menu(draw, title="FLED TRIM", icon='ERROR')


def _run_uninstall():
    """Runs from a timer, after the operator has finished (the add-on removes itself)."""
    name = __name__
    try:
        if name.startswith("bl_ext."):
            # installed as an Extension: bl_ext.<repo_module>.<package_id>
            _, repo_module, pkg_id = name.split(".", 2)
            repos = bpy.context.preferences.extensions.repos
            idx = next((i for i, r in enumerate(repos) if r.module == repo_module), None)
            if idx is None:
                raise RuntimeError("extension repository not found")
            bpy.ops.extensions.package_uninstall(repo_index=idx, pkg_id=pkg_id)
        else:
            # legacy add-on (single .py or classic zip)
            bpy.ops.preferences.addon_remove(module=name)
    except Exception as ex:  # noqa
        _manual_uninstall_popup(ex)
    return None


class FLEDTRIM_OT_uninstall(bpy.types.Operator):
    bl_idname = "fled_trim.uninstall"
    bl_label = "Uninstall FLED TRIM"
    bl_description = "Disable and remove the FLED TRIM add-on from Blender (your scenes are not modified)"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def draw(self, context):
        col = self.layout.column()
        col.label(text="FLED TRIM will be disabled and removed from Blender.")
        col.label(text="Your scenes and meshes are not modified.")
        col.label(text="Press OK to uninstall.")

    def execute(self, context):
        self.report({'INFO'}, "Uninstalling FLED TRIM...")
        bpy.app.timers.register(_run_uninstall, first_interval=0.2)
        return {'FINISHED'}


class FLEDTRIM_Preferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="FLED TRIM - Box Trim for open and non-manifold meshes")
        col.label(text="Where: 3D Viewport > Sidebar (N) > FLED TRIM")
        col.label(text="Shortcut: Ctrl+Shift+T (editable in Preferences > Keymap)")

        layout.separator()
        row = layout.row()
        row.alert = True
        row.scale_y = 1.3
        row.operator("fled_trim.uninstall", text="Uninstall FLED TRIM", icon='TRASH')

        row = layout.row()
        row.alignment = 'RIGHT'
        row.scale_y = 0.6
        row.enabled = False
        row.label(text="by Hawk_eyes42")


# ---------------------------------------------------------------------------
#  User interface
# ---------------------------------------------------------------------------

class FLEDTRIM_PT_panel(bpy.types.Panel):
    bl_label = "FLED TRIM"
    bl_idname = "FLEDTRIM_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "FLED TRIM"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        col = layout.column(align=True)
        col.label(text="1. Choose what to remove")
        row = col.row(align=True)
        row.scale_y = 1.4
        row.prop(scene, "fled_trim_mode", expand=True)

        layout.separator()
        col = layout.column(align=True)
        col.label(text="2. Draw the box")
        row = col.row(align=True)
        row.scale_y = 1.8
        row.operator("fled_trim.box_trim", text="BOX TRIM", icon='SELECT_SET')

        layout.separator()
        box = layout.box()
        col = box.column(align=True)
        col.scale_y = 0.85
        col.label(text="Shortcut: Ctrl+Shift+T")
        col.label(text="While drawing: TAB = inside/outside")
        col.label(text="ESC / right mouse = cancel")
        col.label(text="Cuts through everything (X-ray) on the")
        col.label(text="selected meshes, in Object Mode.")

        # small author credit
        row = layout.row()
        row.alignment = 'RIGHT'
        row.scale_y = 0.6
        row.enabled = False
        row.label(text="by Hawk_eyes42")


def _menu_func(self, context):
    self.layout.separator()
    self.layout.operator(FLEDTRIM_OT_box_trim.bl_idname, text="FLED TRIM - Box Trim", icon='SELECT_SET')


# ---------------------------------------------------------------------------
#  Registration
# ---------------------------------------------------------------------------

_classes = (FLEDTRIM_OT_box_trim, FLEDTRIM_OT_uninstall, FLEDTRIM_Preferences, FLEDTRIM_PT_panel)
_keymaps = []


def register():
    for c in _classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.fled_trim_mode = EnumProperty(
        name="Mode",
        description="Which part to remove relative to the box",
        items=[
            ('INSIDE', "Cut INSIDE", "Remove what is INSIDE the box"),
            ('OUTSIDE', "Cut OUTSIDE", "Remove what is OUTSIDE the box (keep only the boxed part)"),
        ],
        default='INSIDE',
    )

    bpy.types.VIEW3D_MT_object.append(_menu_func)

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon if wm else None
    if kc:
        km = kc.keymaps.new(name="Object Mode", space_type='EMPTY')
        kmi = km.keymap_items.new(FLEDTRIM_OT_box_trim.bl_idname, 'T', 'PRESS', ctrl=True, shift=True)
        _keymaps.append((km, kmi))


def unregister():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _keymaps.clear()

    try:
        bpy.types.VIEW3D_MT_object.remove(_menu_func)
    except Exception:
        pass

    if hasattr(bpy.types.Scene, "fled_trim_mode"):
        del bpy.types.Scene.fled_trim_mode

    for c in reversed(_classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
